# Students - Indoor - Non_Masked > 2023-11-26 10:55pm
https://universe.roboflow.com/miniproject01computervision/students-indoor-non_masked

Provided by a Roboflow user
License: CC BY 4.0

